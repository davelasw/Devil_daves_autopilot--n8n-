# n8n on Render

This repo deploys [n8n](https://n8n.io) to Render with persistent storage and basic authentication.

## 🚀 Quick Deploy Steps

1. **Create a GitHub Repo**
   - Go to [GitHub](https://github.com/new)
   - Name it something like `n8n-render`
   - Upload the files from this repo (`Dockerfile`, `render.yaml`, `README.md`)

2. **Connect to Render**
   - Log in at [Render](https://dashboard.render.com/)
   - Click **New → Web Service**
   - Select **Build from a Repo**
   - Connect your GitHub and pick the repo you just created

3. **Render Auto-Detects Settings**
   - It will see `render.yaml` and configure everything automatically
   - Select **Free Plan** (or Starter if you want more performance)
   - Click **Deploy Web Service**

4. **Set Your Environment Variables**
   - After deployment, go to the **Environment tab**
   - Make sure these exist:
     - `N8N_HOST=n8n.onrender.com` (replace with your Render URL)
     - `N8N_PORT=5678`
     - `N8N_PROTOCOL=https`
     - `WEBHOOK_URL=https://n8n.onrender.com/`
     - `N8N_BASIC_AUTH_ACTIVE=true`
     - `N8N_BASIC_AUTH_USER=admin`
     - `N8N_BASIC_AUTH_PASSWORD=supersecretpassword` (change this!)

5. **Persistent Data**
   - Render mounts a disk at `/home/node/.n8n` to keep your workflows saved
   - No data loss after restarts

6. **Access Your n8n**
   - Once live, go to:  
     `https://<your-service-name>.onrender.com`
   - Log in with the username/password you set above

---

## 🔐 Notes
- Change the `N8N_BASIC_AUTH_PASSWORD` to something strong
- On the free plan, your service sleeps after inactivity. It will wake up automatically on first visit.
